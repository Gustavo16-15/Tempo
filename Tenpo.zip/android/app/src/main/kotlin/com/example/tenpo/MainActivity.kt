package com.example.tenpo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
